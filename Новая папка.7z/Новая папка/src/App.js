import React from "react";

class Header1 extends React.Component {
    render() {
        return (
            <header>{this.props.title}</header>
        )
    }
}

class App extends React.Component {
    helpText = "Help text!";
    render() {
        return (
            <div>
                <Header1 title="Шапка сайта"/>
                <Header1 title="!!!"/>
                <h1>{this.helpText}</h1>
                <input placeholder = {this.helpText}  onClick = {this.inputClick} />
                <p>{this.helpText === "Help text" ? "Y" : "N"}</p>
            </div>)
    }
    inputClick() {console.log("Clicked");}
    }

export default App