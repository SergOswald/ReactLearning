import React from "react";
import * as ReactDomClient from "react-dom/client";
import App from "./App"

// const helpText = "Help text!";

// const inputClick = () => console.log("Clicked");

// class




//component

// function Header () {

// return (
//     <header>Шапка сайта</header>
// )

// }

/*

function App() {

    return (
        <div>
            <Header1/>
            <h1>{helpText}</h1>
            <input placeholder = {helpText}  onClick = {inputClick} />
            <p>{helpText === "Help text" ? "Y" : "N"}</p>
        </div>)
}

*/

//ReactDOM.render( element , app );

const app = ReactDomClient.createRoot(  document.getElementById("app") );

app.render( <App /> )